import React from 'react';
import {
  View, Text, Modal, TouchableOpacity, StyleSheet,
} from 'react-native';

export default function CustomModal({
  visible,
  type = 'info',
  title,
  message,
  confirmText = 'OK',
  cancelText = 'Cancel',
  onConfirm,
  onCancel,
  showCancel = false,
}) {
  const colors = {
    info:    { header: '#1D4ED8', icon: 'ℹ️' },
    success: { header: '#16A34A', icon: '✅' },
    warning: { header: '#D97706', icon: '⚠️' },
    danger:  { header: '#DC2626', icon: '❌' },
    logout:  { header: '#7C3AED', icon: '👋' },
  };
  const c = colors[type] || colors.info;

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.box}>
          <View style={[styles.header, { backgroundColor: c.header }]}>
            <Text style={styles.icon}>{c.icon}</Text>
          </View>
          <View style={styles.body}>
            <Text style={styles.title}>{title}</Text>
            {message ? <Text style={styles.message}>{message}</Text> : null}
          </View>
          <View style={[styles.footer, showCancel && styles.footerRow]}>
            {showCancel && (
              <TouchableOpacity
                style={[styles.btn, styles.cancelBtn]}
                onPress={onCancel}
                activeOpacity={0.8}
              >
                <Text style={styles.cancelText}>{cancelText}</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={[styles.btn, { backgroundColor: c.header }, showCancel && styles.flex1]}
              onPress={onConfirm}
              activeOpacity={0.8}
            >
              <Text style={styles.confirmText}>{confirmText}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay:    { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', alignItems: 'center', justifyContent: 'center', padding: 32 },
  box:        { backgroundColor: '#fff', borderRadius: 20, overflow: 'hidden', width: '100%', maxWidth: 340 },
  header:     { alignItems: 'center', paddingVertical: 24 },
  icon:       { fontSize: 40 },
  body:       { padding: 24, alignItems: 'center' },
  title:      { fontSize: 18, fontWeight: '700', color: '#1A1714', textAlign: 'center', marginBottom: 8 },
  message:    { fontSize: 14, color: '#5C5750', textAlign: 'center', lineHeight: 22 },
  footer:     { padding: 16, paddingTop: 0 },
  footerRow:  { flexDirection: 'row', gap: 10 },
  btn:        { borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  flex1:      { flex: 1 },
  cancelBtn:  { flex: 1, backgroundColor: '#F7F4EF', borderWidth: 1.5, borderColor: '#E5E1D8' },
  cancelText: { fontSize: 14, fontWeight: '600', color: '#5C5750' },
  confirmText:{ fontSize: 14, fontWeight: '700', color: '#fff' },
});
