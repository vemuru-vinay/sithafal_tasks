import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { acknowledgeRequest, flagRequest, getUserProfile } from '../../services/firestore';
import { sendPushNotification, NOTIF } from '../../services/notifications';
import { useAuth } from '../../services/AuthContext';
import {
  Card, InfoRow, StatusChip, PrimaryButton, GhostButton,
  LoadingScreen, Avatar, ApprovalChain, InputField, SectionLabel,
} from '../../components';
import { Colors, Spacing, Radius } from '../../theme';
import CustomModal from '../../components/CustomModal';
import useModal from '../../hooks/useModal';

const FLAG_REASONS = ['Suspicious reason', 'Behavioral concern', 'Previous violations', 'Other'];

export default function MentorRequestDetail({ route, navigation }) {
  const { requestId } = route.params;
  const { profile } = useAuth();
  const [request, setRequest] = useState(null);
  const [note, setNote] = useState('');
  const [showFlagForm, setShowFlagForm] = useState(false);
  const [flagReason, setFlagReason] = useState(FLAG_REASONS[0]);
  const [flagDetail, setFlagDetail] = useState('');
  const [loading, setLoading] = useState(false);
  const { modal, showAlert, showConfirm } = useModal();

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'exitRequests', requestId), snap => {
      if (snap.exists()) setRequest({ id: snap.id, ...snap.data() });
    });
    return unsub;
  }, [requestId]);

  const handleAcknowledge = async () => {
    const confirmed = await showConfirm({
      type: 'success',
      title: 'Acknowledge and release QR?',
      message: 'The student will receive a ready-to-scan QR token after this step.',
      confirmText: 'Release QR',
      cancelText: 'Go Back',
    });

    if (!confirmed) return;

    setLoading(true);
    try {
      await acknowledgeRequest(requestId, profile.uid, note);

      try {
        const studentProfile = await getUserProfile(request.studentId);
        if (studentProfile?.fcmToken) {
          const { title, body } = NOTIF.studentApproved();
          await sendPushNotification(studentProfile.fcmToken, title, body, { requestId, type: 'QR_READY' });
        }
      } catch (_) {}

      await showAlert({
        type: 'success',
        title: 'QR released',
        message: 'The student can now show the QR at the gate.',
      });
      navigation.goBack();
    } catch (err) {
      await showAlert({
        type: 'danger',
        title: 'Unable to acknowledge',
        message: err.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFlag = async () => {
    if (!flagDetail.trim()) {
      await showAlert({
        type: 'warning',
        title: 'Concern details required',
        message: 'Please describe your concern before flagging this request.',
      });
      return;
    }

    const confirmed = await showConfirm({
      type: 'danger',
      title: 'Flag this request?',
      message: 'This will hold the exit request and notify the school for review.',
      confirmText: 'Flag Request',
      cancelText: 'Cancel',
    });

    if (!confirmed) return;

    setLoading(true);
    try {
      await flagRequest(requestId, profile.uid, flagReason, flagDetail);
      setShowFlagForm(false);
      await showAlert({
        type: 'info',
        title: 'Request flagged',
        message: 'The exit has been put on hold for review.',
      });
      navigation.goBack();
    } catch (err) {
      await showAlert({
        type: 'danger',
        title: 'Unable to flag request',
        message: err.message,
      });
    } finally {
      setLoading(false);
    }
  };

  if (!request) return <LoadingScreen color={Colors.mentor} />;

  const needsAction = request.status === 'PARENT_APPROVED';

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.topRow}>
          <Text style={styles.pageTitle}>Mentor Review</Text>
          <StatusChip status={request.status} size="lg" />
        </View>

        <Card style={{ backgroundColor: Colors.mentorBg, borderColor: Colors.mentorMid }} accentTop={Colors.mentor}>
          <View style={styles.studentRow}>
            <Avatar name={request.studentName} color={Colors.student} size={50} />
            <View style={{ flex: 1 }}>
              <Text style={styles.studentName}>{request.studentName}</Text>
              <Text style={styles.studentMeta}>Class {request.studentClass}</Text>
            </View>
            {request.status === 'PARENT_APPROVED' && (
              <View style={styles.parentApprovedBadge}>
                <Text style={styles.parentApprovedText}>Parent Approved</Text>
              </View>
            )}
          </View>
        </Card>

        <Card accentTop={Colors.mentor}>
          <SectionLabel text="Request Details" />
          <InfoRow label="Reason" value={request.reasonCategory} />
          {request.reasonDetail ? <InfoRow label="Details" value={request.reasonDetail} /> : null}
          <InfoRow label="Leave At" value={request.leaveAt} />
          <InfoRow label="Return By" value={request.returnBy} />
          <InfoRow label="Urgency" value={request.urgency} />
        </Card>

        {request.parentApproval && (
          <Card style={{ backgroundColor: Colors.parentBg, borderColor: Colors.parentMid }} accentTop={Colors.parent}>
            <SectionLabel text="Parent Approval Details" />
            <InfoRow
              label="Decision"
              value={request.parentApproval.approved ? 'Approved' : 'Rejected'}
              valueStyle={{ color: request.parentApproval.approved ? Colors.success : Colors.danger }}
            />
            {request.parentApproval.note ? (
              <InfoRow label="Note" value={`"${request.parentApproval.note}"`} valueStyle={{ fontStyle: 'italic' }} />
            ) : null}
            <InfoRow label="At" value={request.parentApproval.at || 'Recorded'} />
          </Card>
        )}

        <Card accentTop={Colors.mentor}>
          <SectionLabel text="Approval Chain" />
          <ApprovalChain status={request.status} />
        </Card>

        {needsAction && (
          <>
            <InputField
              label="Your Note (optional)"
              value={note}
              onChangeText={setNote}
              placeholder="e.g. Student to return before afternoon lab"
              multiline
              numberOfLines={3}
              inputStyle={{ minHeight: 88, textAlignVertical: 'top' }}
            />

            <PrimaryButton
              label="Acknowledge and Release QR"
              color={Colors.success}
              onPress={handleAcknowledge}
              loading={loading}
              style={styles.ackBtn}
            />

            <GhostButton
              label="Flag Concern"
              color={Colors.danger}
              onPress={() => setShowFlagForm(prev => !prev)}
              style={styles.flagBtn}
            />

            {showFlagForm && (
              <Card style={{ backgroundColor: Colors.dangerBg, borderColor: '#FCA5A5' }} accentTop={Colors.danger}>
                <SectionLabel text="Flag Reason" />
                <View style={styles.flagOptionsWrap}>
                  {FLAG_REASONS.map((reason) => (
                    <TouchableOpacity
                      key={reason}
                      style={[styles.flagOption, flagReason === reason && styles.flagOptionActive]}
                      onPress={() => setFlagReason(reason)}
                    >
                      <Text style={[styles.flagOptionText, flagReason === reason && styles.flagOptionTextActive]}>{reason}</Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <InputField
                  label="Describe Your Concern"
                  value={flagDetail}
                  onChangeText={setFlagDetail}
                  placeholder="Explain why the request should be held"
                  multiline
                  numberOfLines={4}
                  required
                  inputStyle={{ minHeight: 100, textAlignVertical: 'top' }}
                />

                <Text style={styles.flagWarning}>Exit will be held and the school will be notified for review.</Text>

                <PrimaryButton
                  label="Submit Flag"
                  color={Colors.danger}
                  onPress={handleFlag}
                  loading={loading}
                  style={{ marginTop: Spacing.sm }}
                />
              </Card>
            )}
          </>
        )}

        {request.status === 'MENTOR_FLAGGED' && (
          <Card style={{ backgroundColor: Colors.dangerBg, borderColor: '#FCA5A5' }} accentTop={Colors.danger}>
            <Text style={styles.stateTitle}>🚩 You flagged this request</Text>
            <Text style={styles.stateText}>Reason: {request.mentorApproval?.flagReason}</Text>
            <Text style={styles.stateText}>{request.mentorApproval?.flagDetail}</Text>
            <Text style={styles.stateNote}>Admin has been notified and exit remains on hold.</Text>
          </Card>
        )}
      </ScrollView>
      <CustomModal {...modal} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  scroll: { padding: Spacing.lg, paddingBottom: 40 },
  topRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md, gap: 12 },
  pageTitle: { fontSize: 22, fontWeight: '700', color: Colors.ink, flex: 1 },
  studentRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  studentName: { fontSize: 18, fontWeight: '700', color: Colors.ink },
  studentMeta: { fontSize: 13, color: Colors.ink2, marginTop: 4 },
  parentApprovedBadge: { backgroundColor: Colors.successBg, borderRadius: Radius.full, paddingHorizontal: 10, paddingVertical: 7 },
  parentApprovedText: { fontSize: 12, color: Colors.success, fontWeight: '700' },
  ackBtn: { minHeight: 56 },
  flagBtn: { marginTop: Spacing.sm, borderStyle: 'solid', backgroundColor: '#FFF6F6' },
  flagOptionsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: Spacing.md },
  flagOption: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: Radius.full, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.surface },
  flagOptionActive: { borderColor: Colors.danger, backgroundColor: '#FFF1F2' },
  flagOptionText: { fontSize: 13, color: Colors.ink2 },
  flagOptionTextActive: { color: Colors.danger, fontWeight: '700' },
  flagWarning: { fontSize: 13, color: Colors.danger, lineHeight: 20 },
  stateTitle: { fontSize: 15, fontWeight: '700', color: Colors.danger },
  stateText: { fontSize: 13, color: Colors.ink2, marginTop: 4, lineHeight: 20 },
  stateNote: { fontSize: 13, color: Colors.ink3, marginTop: 8 },
});
