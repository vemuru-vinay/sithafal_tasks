import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../services/AuthContext';
import { Card, PrimaryButton, SectionLabel } from '../../components';
import { Colors, Spacing, Radius, Shadow } from '../../theme';
import CustomModal from '../../components/CustomModal';
import useModal from '../../hooks/useModal';

export default function GateScanner({ navigation }) {
  const { profile } = useAuth();
  const [token, setToken] = useState('');
  const [verifying, setVerifying] = useState(false);
  const { modal, showAlert } = useModal();

  const handlePaste = async () => {
    try {
      if (Platform.OS === 'web' && typeof navigator !== 'undefined' && navigator.clipboard?.readText) {
        const value = await navigator.clipboard.readText();
        if (value) {
          setToken(value.trim());
          return;
        }
      }

      await showAlert({
        type: 'info',
        title: 'Paste not available',
        message: 'Paste support is available on web with clipboard permission. On mobile, copy the token and enter it manually.',
      });
    } catch (error) {
      await showAlert({
        type: 'warning',
        title: 'Unable to paste',
        message: error.message || 'Clipboard access was not available.',
      });
    }
  };

  const handleVerify = async () => {
    if (!token.trim()) {
      await showAlert({
        type: 'warning',
        title: 'Token required',
        message: 'Please enter or paste the student QR token first.',
      });
      return;
    }

    setVerifying(true);
    navigation.navigate('GateVerify', { qrToken: token.trim() });
    setToken('');
    setVerifying(false);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.body}>
        <Card style={styles.heroCard} accentTop={Colors.gate}>
          <Text style={styles.heroEyebrow}>Gate Dashboard</Text>
          <Text style={styles.heroTitle}>{profile?.name || 'Gate Staff'}</Text>
          <Text style={styles.heroSub}>{profile?.gateId || 'Main Gate'} verification console for student exit passes.</Text>
        </Card>

        <Card style={styles.instructionCard} accentTop={Colors.gate}>
          <SectionLabel text="How It Works" />
          <Text style={styles.instructionText}>1. Ask the student to open their approved exit QR.</Text>
          <Text style={styles.instructionText}>2. Paste or type the token below.</Text>
          <Text style={styles.instructionText}>3. Verify the request before allowing exit.</Text>
        </Card>

        <Card style={styles.scanCard} accentTop={Colors.gate}>
          <Text style={styles.scanIcon}>🎫</Text>
          <Text style={styles.scanTitle}>Enter Student QR Token</Text>
          <Text style={styles.scanSub}>Use the token from the student app to verify approval at the gate.</Text>

          <View style={styles.inputRow}>
            <TextInput
              style={styles.tokenInput}
              placeholder="e.g. SP-ABC123-XYZ456"
              placeholderTextColor={Colors.ink3}
              value={token}
              onChangeText={setToken}
              autoCapitalize="characters"
              autoCorrect={false}
            />
            <TouchableOpacity style={styles.pasteBtn} onPress={handlePaste} activeOpacity={0.85}>
              <Text style={styles.pasteBtnText}>Paste</Text>
            </TouchableOpacity>
          </View>

          <PrimaryButton
            label="Verify Token"
            onPress={handleVerify}
            loading={verifying}
            color={Colors.gate}
            style={styles.verifyBtn}
          />
        </Card>

        <TouchableOpacity
          style={styles.manualBtn}
          onPress={() => navigation.navigate('GateManualSearch')}
          activeOpacity={0.8}
        >
          <Text style={styles.manualIcon}>👥</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.manualTitle}>Manual Search</Text>
            <Text style={styles.manualSub}>Search by student name, ID, or roll number</Text>
          </View>
          <Text style={styles.manualArrow}>›</Text>
        </TouchableOpacity>
      </View>
      <CustomModal {...modal} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.gateBg },
  body: { flex: 1, padding: Spacing.lg },
  heroCard: { ...Shadow.sm },
  heroEyebrow: { fontSize: 13, color: Colors.gate, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8 },
  heroTitle: { fontSize: 24, fontWeight: '700', color: Colors.ink, marginTop: 6 },
  heroSub: { fontSize: 14, color: Colors.ink2, marginTop: 6, lineHeight: 22 },
  instructionCard: { backgroundColor: '#FBF8FF' },
  instructionText: { fontSize: 13, color: Colors.ink2, lineHeight: 22, marginTop: 4 },
  scanCard: { alignItems: 'center' },
  scanIcon: { fontSize: 48, marginBottom: 12 },
  scanTitle: { fontSize: 20, fontWeight: '700', color: Colors.ink, marginBottom: 8 },
  scanSub: { fontSize: 14, color: Colors.ink2, textAlign: 'center', lineHeight: 22, marginBottom: 20 },
  inputRow: { width: '100%', flexDirection: 'row', gap: 10, alignItems: 'center' },
  tokenInput: { flex: 1, backgroundColor: Colors.surface, borderWidth: 1.5, borderColor: Colors.border, borderRadius: Radius.md, minHeight: 58, paddingHorizontal: 16, fontSize: 17, color: Colors.ink, fontFamily: 'monospace', textAlign: 'center', letterSpacing: 1 },
  pasteBtn: { minHeight: 58, minWidth: 88, borderRadius: Radius.md, backgroundColor: '#EDE9FE', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16 },
  pasteBtnText: { color: Colors.gate, fontSize: 14, fontWeight: '700' },
  verifyBtn: { width: '100%', marginTop: Spacing.md, minHeight: 56 },
  manualBtn: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.surface, borderRadius: Radius.md, padding: Spacing.md, borderWidth: 1, borderColor: Colors.gateMid, marginTop: Spacing.sm },
  manualIcon: { fontSize: 28 },
  manualTitle: { fontSize: 15, fontWeight: '700', color: Colors.ink },
  manualSub: { fontSize: 13, color: Colors.ink2, marginTop: 2 },
  manualArrow: { fontSize: 24, color: Colors.ink3 },
});
