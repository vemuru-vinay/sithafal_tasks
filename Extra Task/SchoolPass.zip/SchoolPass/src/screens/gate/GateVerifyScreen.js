import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Vibration,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getRequestByQRToken, confirmExit, getUserProfile } from '../../services/firestore';
import { sendPushNotification, NOTIF } from '../../services/notifications';
import { useAuth } from '../../services/AuthContext';
import {
  Card, InfoRow, StatusChip, PrimaryButton, GhostButton,
  LoadingScreen, Avatar,
} from '../../components';
import { Colors, Spacing } from '../../theme';
import CustomModal from '../../components/CustomModal';
import useModal from '../../hooks/useModal';

export default function GateVerifyScreen({ route, navigation }) {
  const { qrToken } = route.params;
  const { profile } = useAuth();
  const [request, setRequest] = useState(null);
  const [confirming, setConfirming] = useState(false);
  const [done, setDone] = useState(false);
  const { modal, showAlert } = useModal();

  useEffect(() => {
    lookupToken();
  }, [qrToken]);

  const lookupToken = async () => {
    try {
      const req = await getRequestByQRToken(qrToken);
      if (!req) {
        setRequest(false);
        Vibration.vibrate([0, 100, 100, 100]);
      } else {
        setRequest(req);
        if (req.status === 'MENTOR_ACKNOWLEDGED') {
          Vibration.vibrate(200);
        } else {
          Vibration.vibrate([0, 100, 100, 100]);
        }
      }
    } catch (_) {
      setRequest(false);
    }
  };

  const handleConfirmExit = async () => {
    setConfirming(true);
    try {
      await confirmExit(request.id, profile.uid, profile.gateId || 'GATE-01');

      try {
        const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const [parentProfile, mentorProfile] = await Promise.all([
          getUserProfile(request.parentId),
          getUserProfile(request.mentorId),
        ]);
        const { title, body } = NOTIF.exitConfirmed(request.studentName, now);
        if (parentProfile?.fcmToken) {
          await sendPushNotification(parentProfile.fcmToken, title, body, { requestId: request.id, type: 'EXITED' });
        }
        if (mentorProfile?.fcmToken) {
          await sendPushNotification(mentorProfile.fcmToken, title, body, { requestId: request.id, type: 'EXITED' });
        }
      } catch (_) {}

      setDone(true);
    } catch (err) {
      await showAlert({
        type: 'danger',
        title: 'Verification failed',
        message: err.message,
      });
    } finally {
      setConfirming(false);
    }
  };

  if (request === null) {
    return (
      <SafeAreaView style={styles.safe}>
        <LoadingScreen color={Colors.gate} />
        <Text style={styles.loadingText}>Verifying QR code...</Text>
        <CustomModal {...modal} />
      </SafeAreaView>
    );
  }

  if (done) {
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.doneScreen}>
          <View style={[styles.doneIcon, { backgroundColor: Colors.successBg }]}>
            <Text style={{ fontSize: 48 }}>✅</Text>
          </View>
          <Text style={styles.doneTitle}>Exit Logged</Text>
          <Text style={styles.doneSub}>{request.studentName} exited at {now}</Text>

          <Card style={{ marginTop: Spacing.xl, width: '100%' }} accentTop={Colors.success}>
            <InfoRow label="Student" value={request.studentName} />
            <InfoRow label="Exit Time" value={now} valueStyle={{ color: Colors.success }} />
            <InfoRow label="Return By" value={request.returnBy} />
            <InfoRow label="Log ID" value={request.id?.slice(-8).toUpperCase()} />
          </Card>

          <Text style={styles.notifiedText}>✓ Parent and mentor have been notified</Text>

          <PrimaryButton
            label="Scan Next Student"
            color={Colors.gate}
            onPress={() => navigation.popToTop()}
            style={{ marginTop: Spacing.xl, width: '100%' }}
          />
        </View>
        <CustomModal {...modal} />
      </SafeAreaView>
    );
  }

  if (request === false) {
    return (
      <SafeAreaView style={[styles.safe, { backgroundColor: Colors.dangerBg }]}>
        <View style={styles.deniedScreen}>
          <View style={[styles.deniedHeader, { backgroundColor: Colors.danger }]}>
            <Text style={{ fontSize: 40 }}>🚫</Text>
            <Text style={styles.deniedTitle}>TOKEN INVALID</Text>
            <Text style={styles.deniedSub}>No matching request found</Text>
          </View>
          <ScrollView contentContainerStyle={{ padding: Spacing.lg }}>
            <Card style={{ backgroundColor: Colors.dangerBg, borderColor: '#FCA5A5' }} accentTop={Colors.danger}>
              <Text style={styles.reasonTitle}>Why this failed</Text>
              <Text style={styles.reasonText}>• QR code was not found in the system{'\n'}• Token may already have been used{'\n'}• Student may not have an approved request{'\n'}• QR code may have been tampered with</Text>
            </Card>
            <Card accentTop={Colors.danger}>
              <Text style={styles.reasonTitleDark}>Do NOT allow exit.</Text>
              <Text style={styles.reasonTextDark}>Direct the student to the office. Admin has been auto-alerted.</Text>
            </Card>
            <PrimaryButton
              label="Alert Admin"
              color={Colors.danger}
              onPress={async () => {
                await showAlert({
                  type: 'info',
                  title: 'Admin alerted',
                  message: 'School admin has been notified of this unauthorized exit attempt.',
                });
              }}
              style={{ marginTop: Spacing.sm }}
            />
            <GhostButton
              label="Back to Scanner"
              onPress={() => navigation.popToTop()}
              style={{ marginTop: Spacing.sm }}
            />
          </ScrollView>
        </View>
        <CustomModal {...modal} />
      </SafeAreaView>
    );
  }

  if (request.status === 'EXITED' || (request.gate?.qrUsed && request.status !== 'MENTOR_ACKNOWLEDGED')) {
    return (
      <SafeAreaView style={[styles.safe, { backgroundColor: Colors.gateBg }]}>
        <View style={[styles.deniedHeader, { backgroundColor: Colors.gate }]}>
          <Text style={{ fontSize: 40 }}>⛔</Text>
          <Text style={styles.deniedTitle}>TOKEN ALREADY USED</Text>
          <Text style={styles.deniedSub}>This QR cannot be used again</Text>
        </View>
        <ScrollView contentContainerStyle={{ padding: Spacing.lg }}>
          <Card accentTop={Colors.gate}>
            <InfoRow label="Student" value={request.studentName} />
            <InfoRow label="First Used" value={request.gate?.exitConfirmedAt || 'Earlier today'} />
            <InfoRow label="Status" value={request.status} valueStyle={{ color: Colors.gate }} />
          </Card>
          <Card style={{ backgroundColor: Colors.gateBg, borderColor: Colors.gateMid }} accentTop={Colors.gate}>
            <Text style={styles.reasonTextDark}>If the student is returning, use manual search to log the return. If someone else is trying to use this QR, report it immediately.</Text>
          </Card>
          <PrimaryButton
            label="Search Student Manually"
            color={Colors.gate}
            onPress={() => navigation.navigate('GateManualSearch')}
            style={{ marginTop: Spacing.sm }}
          />
          <GhostButton
            label="Back to Scanner"
            onPress={() => navigation.popToTop()}
            style={{ marginTop: Spacing.sm }}
          />
        </ScrollView>
        <CustomModal {...modal} />
      </SafeAreaView>
    );
  }

  if (request.status !== 'MENTOR_ACKNOWLEDGED') {
    return (
      <SafeAreaView style={[styles.safe, { backgroundColor: Colors.dangerBg }]}>
        <View style={[styles.deniedHeader, { backgroundColor: Colors.danger }]}>
          <Text style={{ fontSize: 40 }}>🚫</Text>
          <Text style={styles.deniedTitle}>EXIT DENIED</Text>
          <Text style={styles.deniedSub}>Approval chain incomplete</Text>
        </View>
        <ScrollView contentContainerStyle={{ padding: Spacing.lg }}>
          <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }} accentTop={Colors.danger}>
            <Avatar name={request.studentName} color={Colors.student} size={44} />
            <View>
              <Text style={{ fontSize: 15, fontWeight: '700', color: Colors.ink }}>{request.studentName}</Text>
              <Text style={{ fontSize: 13, color: Colors.ink2 }}>{request.studentClass}</Text>
            </View>
          </Card>
          <Card style={{ backgroundColor: Colors.dangerBg, borderColor: '#FCA5A5' }} accentTop={Colors.danger}>
            <InfoRow label="Current Status" value={request.status} valueStyle={{ color: Colors.danger }} />
            {request.status === 'PENDING' && <InfoRow label="Blocked by" value="Awaiting parent approval" />}
            {request.status === 'PARENT_APPROVED' && <InfoRow label="Blocked by" value="Awaiting mentor acknowledgement" />}
            {request.status === 'MENTOR_FLAGGED' && <InfoRow label="Blocked by" value="Mentor flagged - admin reviewing" />}
            {request.status === 'REJECTED' && <InfoRow label="Blocked by" value="Parent rejected this request" />}
          </Card>
          <Card accentTop={Colors.danger}>
            <Text style={styles.reasonTitleDark}>Do NOT allow exit.</Text>
            <Text style={styles.reasonTextDark}>The approval chain is not complete. Direct the student to the office.</Text>
          </Card>
          <GhostButton label="Back to Scanner" onPress={() => navigation.popToTop()} style={{ marginTop: Spacing.sm }} />
        </ScrollView>
        <CustomModal {...modal} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.clearedHeader}>
        <Text style={{ fontSize: 40 }}>✅</Text>
        <Text style={styles.clearedTitle}>CLEARED FOR EXIT</Text>
        <Text style={styles.clearedSub}>All approvals verified</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: Spacing.lg }}>
        <Card style={{ borderColor: Colors.success, borderWidth: 1.5 }} accentTop={Colors.success}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Avatar name={request.studentName} color={Colors.student} size={48} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 18, fontWeight: '700', color: Colors.ink }}>{request.studentName}</Text>
              <Text style={{ fontSize: 13, color: Colors.ink2 }}>Class {request.studentClass}</Text>
            </View>
            <StatusChip status="PARENT_APPROVED" />
          </View>
        </Card>

        <Card accentTop={Colors.gate}>
          <InfoRow label="Reason" value={request.reasonCategory} />
          <InfoRow label="Leave At" value={request.leaveAt} />
          <InfoRow label="Return By" value={request.returnBy} />
          <InfoRow label="Approved" value="Parent ✓ Mentor ✓" valueStyle={{ color: Colors.success }} />
        </Card>

        {request.parentApproval?.note ? (
          <Card style={{ backgroundColor: Colors.parentBg, borderColor: Colors.parentMid }} accentTop={Colors.parent}>
            <Text style={styles.noteLabel}>Parent Note</Text>
            <Text style={styles.noteText}>"{request.parentApproval.note}"</Text>
          </Card>
        ) : null}

        {request.mentorApproval?.note ? (
          <Card style={{ backgroundColor: Colors.mentorBg, borderColor: Colors.mentorMid }} accentTop={Colors.mentor}>
            <Text style={styles.noteLabel}>Mentor Note</Text>
            <Text style={styles.noteText}>"{request.mentorApproval.note}"</Text>
          </Card>
        ) : null}

        <PrimaryButton
          label="Confirm Exit and Log"
          loading={confirming}
          color={Colors.success}
          onPress={handleConfirmExit}
          style={{ marginTop: Spacing.md, minHeight: 56 }}
        />
        <GhostButton
          label="Back to Scanner"
          onPress={() => navigation.popToTop()}
          style={{ marginTop: Spacing.sm }}
        />
      </ScrollView>
      <CustomModal {...modal} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  loadingText: { textAlign: 'center', color: Colors.ink3, marginTop: -100, fontSize: 13 },
  doneScreen: { flex: 1, alignItems: 'center', padding: Spacing.xl },
  doneIcon: { width: 100, height: 100, borderRadius: 50, alignItems: 'center', justifyContent: 'center', marginTop: Spacing.xxl },
  doneTitle: { fontSize: 24, fontWeight: '700', color: Colors.success, marginTop: 16 },
  doneSub: { fontSize: 14, color: Colors.ink2, marginTop: 6 },
  notifiedText: { fontSize: 13, color: Colors.success, marginTop: Spacing.lg },
  deniedScreen: { flex: 1 },
  deniedHeader: { padding: Spacing.xl, alignItems: 'center', paddingTop: 60 },
  deniedTitle: { fontSize: 22, fontWeight: '800', color: '#fff', marginTop: 8, letterSpacing: 1 },
  deniedSub: { fontSize: 13, color: 'rgba(255,255,255,0.8)', marginTop: 4 },
  clearedHeader: { backgroundColor: Colors.success, padding: Spacing.xl, alignItems: 'center', paddingTop: 60 },
  clearedTitle: { fontSize: 22, fontWeight: '800', color: '#fff', marginTop: 8, letterSpacing: 1 },
  clearedSub: { fontSize: 13, color: 'rgba(255,255,255,0.85)', marginTop: 4 },
  reasonTitle: { fontSize: 13, fontWeight: '700', color: Colors.danger, marginBottom: 6 },
  reasonText: { fontSize: 13, color: Colors.ink2, lineHeight: 20 },
  reasonTitleDark: { fontSize: 13, fontWeight: '700', color: Colors.ink, marginBottom: 4 },
  reasonTextDark: { fontSize: 13, color: Colors.ink2, lineHeight: 20 },
  noteLabel: { fontSize: 13, color: Colors.ink2, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 },
  noteText: { fontSize: 13, color: Colors.ink, fontStyle: 'italic' },
});
