import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../services/AuthContext';
import { InputField, PrimaryButton } from '../../components';
import { Colors, Spacing, Radius } from '../../theme';
import CustomModal from '../../components/CustomModal';
import useModal from '../../hooks/useModal';

const ROLE_INFO = {
  student: { icon: '🎒', label: 'Student', color: Colors.student },
  parent: { icon: '👨‍👩‍👧', label: 'Parent', color: Colors.parent },
  mentor: { icon: '👩‍🏫', label: 'Mentor', color: Colors.mentor },
  watchman: { icon: '🛡️', label: 'Watchman', color: Colors.gate },
};

const DEMO_ACCOUNTS = [
  { role: 'student', email: 'student@schoolpass.demo', password: 'demo1234', name: 'Arjun Kumar' },
  { role: 'parent', email: 'parent@schoolpass.demo', password: 'demo1234', name: 'Rajesh Kumar' },
  { role: 'mentor', email: 'mentor@schoolpass.demo', password: 'demo1234', name: 'Ms. Priya Sharma' },
  { role: 'watchman', email: 'gate@schoolpass.demo', password: 'demo1234', name: 'R. Gupta' },
];

export default function LoginScreen() {
  const { login } = useAuth();
  const { modal, showAlert } = useModal();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      await showAlert({
        type: 'warning',
        title: 'Missing credentials',
        message: 'Please enter your email and password.',
      });
      return;
    }

    setLoading(true);
    try {
      await login(email.trim().toLowerCase(), password);
    } catch (err) {
      const msg = err.code === 'auth/invalid-credential'
        ? 'Invalid email or password.'
        : err.message;
      await showAlert({
        type: 'danger',
        title: 'Login failed',
        message: msg,
      });
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (account) => {
    setEmail(account.email);
    setPassword(account.password);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <View style={styles.logoBox}>
              <Text style={styles.logoIcon}>🏫</Text>
            </View>
            <Text style={styles.appName}>SchoolPass</Text>
            <Text style={styles.tagline}>Student Exit Permission System</Text>
          </View>

          <View style={styles.formCard}>
            <Text style={styles.formTitle}>Sign In</Text>
            <InputField
              label="Email Address"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              placeholder="your@email.com"
            />
            <InputField
              label="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              placeholder="••••••••"
            />
            <PrimaryButton
              label="Sign In →"
              onPress={handleLogin}
              loading={loading}
              style={{ marginTop: 4 }}
            />
          </View>

          <View style={styles.demoSection}>
            <Text style={styles.demoTitle}>Demo Accounts - tap to fill</Text>
            <View style={styles.demoGrid}>
              {DEMO_ACCOUNTS.map(acc => {
                const info = ROLE_INFO[acc.role];
                return (
                  <TouchableOpacity
                    key={acc.role}
                    style={[styles.demoCard, { borderColor: info.color }]}
                    onPress={() => fillDemo(acc)}
                    activeOpacity={0.7}
                  >
                    <Text style={styles.demoIcon}>{info.icon}</Text>
                    <Text style={[styles.demoRole, { color: info.color }]}>{info.label}</Text>
                    <Text style={styles.demoName}>{acc.name}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <Text style={styles.demoNote}>
              Password for all demo accounts: <Text style={{ fontWeight: '700' }}>demo1234</Text>
            </Text>
          </View>

          <View style={styles.setupNote}>
            <Text style={styles.setupText}>
              ⚙️ First time? See <Text style={{ fontWeight: '700' }}>SETUP.md</Text> to configure Firebase and create demo accounts.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      <CustomModal {...modal} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  scroll: { padding: Spacing.xl, paddingBottom: 40 },
  header: { alignItems: 'center', marginBottom: Spacing.xl, paddingTop: Spacing.xl },
  logoBox: { width: 64, height: 64, borderRadius: 18, backgroundColor: Colors.ink, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  logoIcon: { fontSize: 32 },
  appName: { fontSize: 28, fontWeight: '700', color: Colors.ink, letterSpacing: -0.5 },
  tagline: { fontSize: 13, color: Colors.ink3, marginTop: 4 },
  formCard: { backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.xl, borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.xl },
  formTitle: { fontSize: 18, fontWeight: '700', color: Colors.ink, marginBottom: Spacing.lg },
  demoSection: { marginBottom: Spacing.xl },
  demoTitle: { fontSize: 11, color: Colors.ink3, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10, textAlign: 'center' },
  demoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  demoCard: { flex: 1, minWidth: '44%', backgroundColor: Colors.surface, borderWidth: 1.5, borderRadius: Radius.md, padding: 12, alignItems: 'center' },
  demoIcon: { fontSize: 22, marginBottom: 4 },
  demoRole: { fontSize: 12, fontWeight: '700' },
  demoName: { fontSize: 10, color: Colors.ink3, marginTop: 2, textAlign: 'center' },
  demoNote: { fontSize: 11, color: Colors.ink3, textAlign: 'center', marginTop: 10 },
  setupNote: { backgroundColor: Colors.warnBg, borderRadius: Radius.sm, padding: 12, borderWidth: 1, borderColor: Colors.parentMid },
  setupText: { fontSize: 12, color: Colors.parent, lineHeight: 18 },
});
