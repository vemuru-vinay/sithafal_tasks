// src/screens/student/StudentQRScreen.js
import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, StatusBar, TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import QRCode from 'react-native-qrcode-svg';
import { Colors, Spacing, Radius } from '../../theme';
import { ApprovalChain, Card, InfoRow } from '../../components';

export default function StudentQRScreen({ route, navigation }) {
  const { request } = route.params;

  // Keep screen bright while QR is shown
  useEffect(() => {
    StatusBar.setBarStyle('dark-content');
    return () => StatusBar.setBarStyle('default');
  }, []);

  if (!request?.qrToken) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.center}>
          <Text style={styles.errorText}>QR not available yet</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginTop: 20 }}>
            <Text style={{ color: Colors.student }}>← Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backBtn}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Exit QR Code</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={styles.scroll}>

        {/* Approved banner */}
        <View style={styles.approvedBanner}>
          <Text style={styles.bannerIcon}>✅</Text>
          <Text style={styles.bannerTitle}>Exit Approved</Text>
          <Text style={styles.bannerSub}>Show this QR at the school gate</Text>
        </View>

        {/* QR Code */}
        <View style={styles.qrContainer}>
          <QRCode
            value={request.qrToken}
            size={200}
            color={Colors.ink}
            backgroundColor="white"
            ecl="H"
          />
          <Text style={styles.tokenText}>{request.qrToken}</Text>
          <View style={styles.validityBadge}>
            <Text style={styles.validityText}>⏰ Valid until {request.returnBy}</Text>
          </View>
          <Text style={styles.singleUse}>Single use · Invalidated after gate scan</Text>
        </View>

        {/* Approval chain */}
        <Card style={{ marginTop: Spacing.md }}>
          <ApprovalChain status={request.status} />
        </Card>

        {/* Request details */}
        <Card>
          <InfoRow label="Reason"    value={request.reasonCategory} />
          <InfoRow label="Leave At"  value={request.leaveAt} />
          <InfoRow label="Return By" value={request.returnBy} />
        </Card>

        {/* Parent note */}
        {request.parentApproval?.note ? (
          <Card style={{ backgroundColor: Colors.parentBg, borderColor: Colors.parentMid }}>
            <Text style={{ fontSize: 10, color: Colors.parent, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>Parent Note</Text>
            <Text style={{ fontSize: 13, color: Colors.ink, fontStyle: 'italic' }}>"{request.parentApproval.note}"</Text>
          </Card>
        ) : null}

      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:    { flex: 1, backgroundColor: Colors.bg },
  center:  { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorText:{ fontSize: 16, color: Colors.ink2 },
  header:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Colors.border },
  backBtn: { fontSize: 15, color: Colors.student, fontWeight: '500', width: 60 },
  headerTitle: { fontSize: 16, fontWeight: '700', color: Colors.ink },
  scroll:  { flex: 1, padding: Spacing.lg },
  approvedBanner: { alignItems: 'center', marginBottom: Spacing.lg },
  bannerIcon:  { fontSize: 40, marginBottom: 8 },
  bannerTitle: { fontSize: 22, fontWeight: '700', color: Colors.success },
  bannerSub:   { fontSize: 13, color: Colors.ink2, marginTop: 4 },
  qrContainer: { backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.xl, alignItems: 'center', borderWidth: 2, borderColor: Colors.ink, marginBottom: Spacing.sm },
  tokenText:   { fontSize: 11, fontFamily: 'monospace', color: Colors.ink2, marginTop: 12, letterSpacing: 1 },
  validityBadge:{ backgroundColor: Colors.studentBg, borderRadius: Radius.full, paddingHorizontal: 14, paddingVertical: 5, marginTop: 8 },
  validityText:  { fontSize: 12, color: Colors.student, fontWeight: '600' },
  singleUse:   { fontSize: 10, color: Colors.ink3, marginTop: 6 },
});
