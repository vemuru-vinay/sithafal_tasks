import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../services/AuthContext';
import { createExitRequest, getUserProfile } from '../../services/firestore';
import { sendPushNotification, NOTIF } from '../../services/notifications';
import { InputField, PrimaryButton, GhostButton, Card, Avatar, SectionLabel } from '../../components';
import { Colors, Spacing, Radius, Shadow } from '../../theme';
import CustomModal from '../../components/CustomModal';
import useModal from '../../hooks/useModal';

const REASON_CATEGORIES = [
  'Medical Appointment',
  'Family Emergency',
  'Personal Reason',
  'Sports / Activity',
  'Other',
];

const URGENCY_LEVELS = ['Normal', 'Urgent', 'Emergency'];

export default function StudentRequestScreen({ navigation }) {
  const { profile } = useAuth();
  const { modal, showAlert } = useModal();

  const [reasonCategory, setReasonCategory] = useState('Medical Appointment');
  const [reasonDetail, setReasonDetail] = useState('');
  const [leaveAt, setLeaveAt] = useState('');
  const [returnBy, setReturnBy] = useState('');
  const [urgency, setUrgency] = useState('Normal');
  const [submitting, setSubmitting] = useState(false);

  const validate = async () => {
    if (!leaveAt.trim()) {
      await showAlert({
        type: 'warning',
        title: 'Leave time required',
        message: 'Please enter the leave time, for example 11:30 AM.',
      });
      return false;
    }

    if (!returnBy.trim()) {
      await showAlert({
        type: 'warning',
        title: 'Return time required',
        message: 'Please enter the return time, for example 2:00 PM.',
      });
      return false;
    }

    return true;
  };

  const handleSubmit = async () => {
    const isValid = await validate();
    if (!isValid) return;

    setSubmitting(true);
    try {
      const requestId = await createExitRequest({
        studentId: profile.uid,
        studentName: profile.name,
        studentClass: profile.class,
        rollNo: profile.rollNo,
        parentId: profile.parentId,
        mentorId: profile.mentorId,
        reasonCategory,
        reasonDetail: reasonDetail.trim(),
        urgency,
        leaveAt: leaveAt.trim(),
        returnBy: returnBy.trim(),
      });

      try {
        const parentProfile = await getUserProfile(profile.parentId);
        if (parentProfile?.fcmToken) {
          const { title, body } = NOTIF.parentRequest(profile.name);
          await sendPushNotification(parentProfile.fcmToken, title, body, { requestId, type: 'PARENT_ACTION' });
        }
      } catch (notifErr) {
        console.log('Parent notification failed (non-fatal):', notifErr.message);
      }

      await showAlert({
        type: 'success',
        title: 'Request sent',
        message: 'Your parent has been notified instantly.',
      });
      navigation.replace('StudentDashboard');
    } catch (err) {
      await showAlert({
        type: 'danger',
        title: 'Submission failed',
        message: err.message,
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <Card style={styles.progressCard} accentTop={Colors.student}>
          <Text style={styles.progressLabel}>Step 1 of 3</Text>
          <Text style={styles.progressTitle}>Create Your Exit Request</Text>
          <Text style={styles.progressSub}>Fill in the details below. Parent approval and mentor review happen next.</Text>
          <View style={styles.progressBarTrack}>
            <View style={styles.progressBarFill} />
          </View>
        </Card>

        <Card style={{ backgroundColor: Colors.studentBg, borderColor: Colors.studentMid }} accentTop={Colors.student}>
          <View style={styles.identityRow}>
            <Avatar name={profile?.name} color={Colors.student} size={44} />
            <View>
              <Text style={styles.identityName}>{profile?.name}</Text>
              <Text style={styles.identityMeta}>{profile?.class} · Roll {profile?.rollNo}</Text>
            </View>
          </View>
        </Card>

        <Card accentTop={Colors.student}>
          <SectionLabel text="Reason Section" />
          <Text style={styles.sectionIntro}>Choose the category that best describes why you need to leave campus.</Text>
          <View style={styles.pillRow}>
            {REASON_CATEGORIES.map((cat) => (
              <TouchableOpacity
                key={cat}
                style={[styles.pill, reasonCategory === cat && styles.pillActive]}
                onPress={() => setReasonCategory(cat)}
              >
                <Text style={[styles.pillText, reasonCategory === cat && styles.pillTextActive]}>{cat}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <InputField
            label="Additional Details"
            value={reasonDetail}
            onChangeText={setReasonDetail}
            placeholder="e.g. Dental checkup at City Hospital"
            multiline
            numberOfLines={3}
            inputStyle={{ minHeight: 88, textAlignVertical: 'top' }}
          />
        </Card>

        <Card accentTop={Colors.student}>
          <SectionLabel text="Time Section" />
          <Text style={styles.sectionIntro}>Set when you plan to leave and when you expect to return.</Text>
          <View style={styles.timeRow}>
            <View style={{ flex: 1 }}>
              <InputField
                label="Leave At"
                value={leaveAt}
                onChangeText={setLeaveAt}
                placeholder="11:30 AM"
                required
              />
            </View>
            <View style={{ flex: 1 }}>
              <InputField
                label="Return By"
                value={returnBy}
                onChangeText={setReturnBy}
                placeholder="2:00 PM"
                required
              />
            </View>
          </View>
        </Card>

        <Card accentTop={Colors.student}>
          <SectionLabel text="Priority Section" />
          <Text style={styles.sectionIntro}>Mark how urgent this request is so your parent and mentor can respond quickly.</Text>
          <View style={styles.pillRow}>
            {URGENCY_LEVELS.map((item) => (
              <TouchableOpacity
                key={item}
                style={[
                  styles.pill,
                  urgency === item && styles.pillActive,
                  item === 'Emergency' && urgency === item && { backgroundColor: Colors.danger, borderColor: Colors.danger },
                  item === 'Urgent' && urgency === item && { backgroundColor: Colors.warn, borderColor: Colors.warn },
                ]}
                onPress={() => setUrgency(item)}
              >
                <Text style={[styles.pillText, urgency === item && styles.pillTextActive]}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <PrimaryButton
          label="Submit Request →"
          onPress={handleSubmit}
          loading={submitting}
          color={Colors.student}
          style={styles.submitBtn}
        />
        <Text style={styles.submitNote}>Your parent will be notified instantly</Text>
        <GhostButton
          label="Cancel"
          onPress={() => navigation.goBack()}
          style={{ marginTop: Spacing.sm }}
        />
      </ScrollView>
      <CustomModal {...modal} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F2F7FF' },
  scroll: { padding: Spacing.lg, paddingBottom: 40 },
  progressCard: { ...Shadow.sm },
  progressLabel: { fontSize: 13, color: Colors.student, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8 },
  progressTitle: { fontSize: 22, fontWeight: '700', color: Colors.ink, marginTop: 6 },
  progressSub: { fontSize: 14, color: Colors.ink2, marginTop: 6, lineHeight: 22 },
  progressBarTrack: { height: 8, backgroundColor: '#DBEAFE', borderRadius: Radius.full, marginTop: Spacing.lg, overflow: 'hidden' },
  progressBarFill: { width: '34%', height: '100%', backgroundColor: Colors.student, borderRadius: Radius.full },
  identityRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  identityName: { fontSize: 16, fontWeight: '700', color: Colors.ink },
  identityMeta: { fontSize: 13, color: Colors.ink2, marginTop: 4 },
  sectionIntro: { fontSize: 13, color: Colors.ink2, marginBottom: Spacing.md, lineHeight: 21 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 10, borderRadius: Radius.full, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.surface, minHeight: 40, justifyContent: 'center' },
  pillActive: { backgroundColor: Colors.student, borderColor: Colors.student },
  pillText: { fontSize: 13, color: Colors.ink2, fontWeight: '500' },
  pillTextActive: { color: '#fff', fontWeight: '700' },
  timeRow: { flexDirection: 'row', gap: 10 },
  submitBtn: { marginTop: Spacing.md, minHeight: 56 },
  submitNote: { fontSize: 13, color: Colors.student, textAlign: 'center', marginTop: 10, marginBottom: 4, fontWeight: '600' },
});
