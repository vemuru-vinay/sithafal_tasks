// src/services/notifications.js
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { updateUserFCMToken } from './firestore';

// Configure how notifications appear when app is in foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

// Register device for push notifications and save token to Firestore
export const registerForPushNotifications = async (uid) => {
  if (!Device.isDevice) {
    console.log('Push notifications require a physical device');
    return null;
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    console.log('Push notification permission denied');
    return null;
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('schoolpass', {
      name: 'SchoolPass Alerts',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#1D4ED8',
      sound: 'default',
    });
  }

  const token = (await Notifications.getExpoPushTokenAsync()).data;

  if (uid && token) {
    await updateUserFCMToken(uid, token);
  }

  return token;
};

// Send a push notification via Expo Push API
// In production, call this from a Cloud Function trigger, not the client
export const sendPushNotification = async (expoPushToken, title, body, data = {}) => {
  const message = {
    to: expoPushToken,
    sound: 'default',
    title,
    body,
    data,
    priority: 'high',
  };

  try {
    await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Accept-encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(message),
    });
  } catch (err) {
    console.error('Push send error:', err);
  }
};

// Notification message templates
export const NOTIF = {
  parentRequest: (studentName) => ({
    title: `Exit Request — ${studentName}`,
    body: 'Your child has submitted an exit request. Tap to approve or reject.',
  }),
  studentApproved: () => ({
    title: '✅ Exit Approved!',
    body: 'Your exit request was approved. Your QR code is ready — show it at the gate.',
  }),
  studentRejected: () => ({
    title: '❌ Request Rejected',
    body: 'Your parent has declined the exit request.',
  }),
  mentorAlert: (studentName) => ({
    title: `Student Exit — ${studentName}`,
    body: 'Parent has approved an exit request. Your acknowledgement is needed.',
  }),
  exitConfirmed: (studentName, time) => ({
    title: `${studentName} has exited`,
    body: `Exited school at ${time}. Please ensure they return on time.`,
  }),
  returnOverdue: (studentName) => ({
    title: `⚠️ Overdue — ${studentName}`,
    body: 'Expected return time has passed. Please follow up immediately.',
  }),
  studentReturned: (studentName, time) => ({
    title: `✓ ${studentName} returned`,
    body: `Returned to school at ${time}.`,
  }),
};
