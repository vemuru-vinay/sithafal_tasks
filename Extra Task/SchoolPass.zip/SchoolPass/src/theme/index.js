// src/theme/index.js

export const Colors = {
  // Base
  bg:       '#F7F4EF',
  bg2:      '#EDEAE3',
  surface:  '#FFFFFF',
  ink:      '#1A1714',
  ink2:     '#5C5750',
  ink3:     '#9B958D',
  border:   '#E5E1D8',

  // Roles
  student:    '#1D4ED8',
  studentBg:  '#EFF6FF',
  studentMid: '#93C5FD',
  parent:     '#B45309',
  parentBg:   '#FFFBEB',
  parentMid:  '#FCD34D',
  mentor:     '#065F46',
  mentorBg:   '#ECFDF5',
  mentorMid:  '#6EE7B7',
  gate:       '#7C3AED',
  gateBg:     '#F5F3FF',
  gateMid:    '#C4B5FD',

  // States
  danger:    '#DC2626',
  dangerBg:  '#FEF2F2',
  success:   '#16A34A',
  successBg: '#F0FDF4',
  warn:      '#D97706',
  warnBg:    '#FFFBEB',
};

export const Fonts = {
  regular: { fontFamily: 'System', fontWeight: '400' },
  medium:  { fontFamily: 'System', fontWeight: '500' },
  semibold:{ fontFamily: 'System', fontWeight: '600' },
  bold:    { fontFamily: 'System', fontWeight: '700' },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

// Reusable style helpers
export const Shadow = {
  sm: {
    shadowColor: '#1A1714',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  md: {
    shadowColor: '#1A1714',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },
};

// Status chip colors
export const statusColors = {
  PENDING:              { bg: '#FFFBEB', text: '#D97706', dot: '#D97706' },
  PARENT_APPROVED:      { bg: '#F0FDF4', text: '#16A34A', dot: '#16A34A' },
  REJECTED:             { bg: '#FEF2F2', text: '#DC2626', dot: '#DC2626' },
  MENTOR_ACKNOWLEDGED:  { bg: '#EFF6FF', text: '#1D4ED8', dot: '#1D4ED8' },
  MENTOR_FLAGGED:       { bg: '#FEF3C7', text: '#92400E', dot: '#D97706' },
  GATE_VERIFIED:        { bg: '#F5F3FF', text: '#7C3AED', dot: '#7C3AED' },
  EXITED:               { bg: '#F5F3FF', text: '#7C3AED', dot: '#7C3AED' },
  RETURNED:             { bg: '#F0FDF4', text: '#16A34A', dot: '#16A34A' },
  OVERDUE:              { bg: '#FEF2F2', text: '#DC2626', dot: '#DC2626' },
  EXPIRED:              { bg: '#F1F5F9', text: '#64748B', dot: '#94A3B8' },
  WITHDRAWN:            { bg: '#F1F5F9', text: '#64748B', dot: '#94A3B8' },
};

export const statusLabel = {
  PENDING:              'Pending',
  PARENT_APPROVED:      'Parent Approved',
  REJECTED:             'Rejected',
  MENTOR_ACKNOWLEDGED:  'QR Ready',
  MENTOR_FLAGGED:       'Flagged',
  GATE_VERIFIED:        'At Gate',
  EXITED:               'Exited',
  RETURNED:             'Returned',
  OVERDUE:              'Overdue',
  EXPIRED:              'Expired',
  WITHDRAWN:            'Withdrawn',
};
